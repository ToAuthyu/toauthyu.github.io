将你想换的配置重命名为和光影压缩包相同的文件名即可
(比如光影包是 ComplementaryShaders_3.12.zip, 它的配置文件就叫 ComplementaryShaders_3.12.zip.txt)
或者你也可以打开ComplementaryShaders_3.12.zip.txt然后把里面的内容删掉，再把你想换的配置的内容复制粘贴进去
更换后需要重启游戏